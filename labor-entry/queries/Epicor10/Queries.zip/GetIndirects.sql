SELECT
	i.IndirectCode
	, i.Description
FROM
	Erp.Indirect i with(nolock)