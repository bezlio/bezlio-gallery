SELECT
	i.IndirectCode
	, i.Description
FROM
	Indirect i with(nolock)