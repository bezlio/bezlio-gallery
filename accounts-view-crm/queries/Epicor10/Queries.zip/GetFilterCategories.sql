
select distinct
	{Col} as Type
from Customer
union
select 'All'